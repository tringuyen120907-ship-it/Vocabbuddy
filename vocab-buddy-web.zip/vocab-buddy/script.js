// Utility: deterministic pick using day-of-year seed
function dayOfYearSeed() {
  const d = new Date();
  const start = new Date(d.getFullYear(), 0, 0);
  const diff = d - start + ((start.getTimezoneOffset() - d.getTimezoneOffset()) * 60 * 1000);
  const day = Math.floor(diff / (1000 * 60 * 60 * 24));
  return day;
}

const TOPIC_KEYS = Object.keys(VOCAB_TOPICS);
const dayIdx = dayOfYearSeed();
const topicIdx = dayIdx % TOPIC_KEYS.length;
const TODAY_TOPIC = TOPIC_KEYS[topicIdx];
const TOPIC_LIST = VOCAB_TOPICS[TODAY_TOPIC] || [];
const DAILY_COUNT = 5;
const TODAY_DECK = TOPIC_LIST.slice(0, DAILY_COUNT);

// progress in localStorage
const LS_KEY = 'vocabbuddy_progress_v1';
let progress = {};
try { progress = JSON.parse(localStorage.getItem(LS_KEY)) || {}; } catch(e){ progress = {}; }
const todayKey = new Date().toISOString().slice(0,10); // YYYY-MM-DD
if (!progress[todayKey]) { progress[todayKey] = { topic: TODAY_TOPIC, done: [] }; localStorage.setItem(LS_KEY, JSON.stringify(progress)); }

// UI refs
const topicBox = document.getElementById('topicBox');
const cardArea = document.getElementById('cardArea');
const prevBtn = document.getElementById('prev');
const nextBtn = document.getElementById('next');
const flipBtn = document.getElementById('flip');
const speakBtn = document.getElementById('speakBtn');
const resetBtn = document.getElementById('resetBtn');
const progressBox = document.getElementById('progress');
const doneBox = document.getElementById('done');

let idx = 0;
let flipped = false;

function renderTopic() {
  topicBox.textContent = `Chủ đề hôm nay: ${TODAY_TOPIC}`;
  progressBox.textContent = `Từ ${idx+1} / ${TODAY_DECK.length}`;
}

function renderCard() {
  cardArea.innerHTML = '';
  if (idx >= TODAY_DECK.length) {
    // mark done
    doneBox.style.display = 'block';
    progressBox.style.display = 'none';
    return;
  } else {
    doneBox.style.display = 'none';
    progressBox.style.display = 'block';
  }

  const item = TODAY_DECK[idx];
  const card = document.createElement('div');
  card.className = 'card';
  card.tabIndex = 0;

  const inner = document.createElement('div');
  inner.className = 'card-inner';

  const front = document.createElement('div');
  front.className = 'face front';
  front.innerHTML = `<div>${item.word}</div><div class="sub">${item.meaning}</div>`;

  const back = document.createElement('div');
  back.className = 'face back';
  back.innerHTML = `<div class="meaning">${item.meaning}</div>
    <div class="example"><strong>EN:</strong> ${item.example_en}<br/><strong>VN:</strong> ${item.example_vn}</div>
    <div style="margin-top:8px"><button id="speakInner">🔊 Phát âm</button></div>`;

  inner.appendChild(front);
  inner.appendChild(back);
  card.appendChild(inner);

  card.addEventListener('click', () => {
    flipped = !flipped;
    if (flipped) card.classList.add('flipped'); else card.classList.remove('flipped');
  });

  // keyboard controls
  card.addEventListener('keydown', (e) => {
    if (e.code === 'Space') { e.preventDefault(); card.click(); }
    if (e.code === 'ArrowRight') nextCard();
    if (e.code === 'ArrowLeft') prevCard();
  });

  cardArea.appendChild(card);
  setTimeout(() => card.focus(), 120);

  // inner speak button
  setTimeout(()=>{
    const speakInner = document.getElementById('speakInner');
    if (speakInner) speakInner.addEventListener('click', (ev)=>{ ev.stopPropagation(); speak(item.word); });
  },200);
}

function nextCard() {
  // mark as learned
  const today = new Date().toISOString().slice(0,10);
  if (!progress[today]) progress[today] = { topic: TODAY_TOPIC, done: [] };
  if (!progress[today].done.includes(TODAY_DECK[idx].word)) {
    progress[today].done.push(TODAY_DECK[idx].word);
    localStorage.setItem(LS_KEY, JSON.stringify(progress));
  }
  idx++; flipped=false; renderTopic(); renderCard();
}

function prevCard() {
  if (idx>0) { idx--; flipped=false; renderTopic(); renderCard(); }
}

function flipCard() {
  const card = cardArea.querySelector('.card');
  if (!card) return;
  flipped = !flipped;
  if (flipped) card.classList.add('flipped'); else card.classList.remove('flipped');
}

function speak(text) {
  if (!('speechSynthesis' in window)) return alert('Trình duyệt không hỗ trợ Speech Synthesis');
  const u = new SpeechSynthesisUtterance(text);
  u.lang = 'en-US';
  window.speechSynthesis.cancel();
  window.speechSynthesis.speak(u);
}

function resetProgress() {
  if (!confirm('Reset tiến độ học?')) return;
  localStorage.removeItem(LS_KEY);
  progress = {};
  alert('Đã reset progress.');
  location.reload();
}

// wire buttons
prevBtn.addEventListener('click', prevCard);
nextBtn.addEventListener('click', nextCard);
flipBtn.addEventListener('click', flipCard);
speakBtn.addEventListener('click', ()=>{ const it = TODAY_DECK[idx]; if (it) speak(it.word); });
resetBtn.addEventListener('click', resetProgress);

renderTopic();
renderCard();