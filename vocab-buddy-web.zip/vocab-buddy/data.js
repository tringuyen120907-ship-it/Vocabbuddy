const VOCAB_TOPICS = {
  "Medical Instruments": [
    {word: "Stethoscope", meaning: "Ống nghe", example_en: "The nurse uses a stethoscope to listen to the patient's heartbeat.", example_vn: "Y tá dùng ống nghe để nghe nhịp tim của bệnh nhân."},
    {word: "Syringe", meaning: "Ống tiêm", example_en: "The doctor prepared a syringe for the injection.", example_vn: "Bác sĩ chuẩn bị ống tiêm để tiêm thuốc."},
    {word: "Thermometer", meaning: "Nhiệt kế", example_en: "She checked the child's fever with a thermometer.", example_vn: "Cô ấy kiểm tra sốt của trẻ bằng nhiệt kế."},
    {word: "Scalpel", meaning: "Dao mổ", example_en: "The surgeon held the scalpel carefully before the incision.", example_vn: "Bác sĩ phẫu thuật cầm dao mổ cẩn thận trước khi rạch."},
    {word: "Forceps", meaning: "Mỏ kẹp (y tế)", example_en: "The nurse used forceps to remove the bandage.", example_vn: "Y tá dùng mỏ kẹp để gỡ băng."},
    {word: "Gauze", meaning: "Gạc y tế", example_en: "Apply sterile gauze to stop the bleeding.", example_vn: "Đặt gạc vô trùng để cầm máu."},
    {word: "Wheelchair", meaning: "Xe lăn", example_en: "The patient was transported to the ward in a wheelchair.", example_vn: "Bệnh nhân được chuyển vào buồng bằng xe lăn."}
  ],
  "Anatomy & Body": [
    {word: "Heart", meaning: "Tim", example_en: "The heart pumps blood through the body.", example_vn: "Tim bơm máu đi khắp cơ thể."},
    {word: "Lung", meaning: "Phổi", example_en: "The lungs help you breathe in oxygen.", example_vn: "Phổi giúp bạn hít oxy."},
    {word: "Liver", meaning: "Gan", example_en: "The liver filters toxins from the blood.", example_vn: "Gan lọc độc tố khỏi máu."},
    {word: "Kidney", meaning: "Thận", example_en: "The kidneys remove waste and balance fluids.", example_vn: "Thận loại bỏ chất thải và cân bằng dịch."},
    {word: "Skin", meaning: "Da", example_en: "Skin protects the body from infection.", example_vn: "Da bảo vệ cơ thể khỏi nhiễm trùng."}
  ],
  "Diseases & Symptoms": [
    {word: "Fever", meaning: "Sốt", example_en: "A high fever may indicate infection.", example_vn: "Sốt cao có thể là dấu hiệu nhiễm trùng."},
    {word: "Cough", meaning: "Ho", example_en: "A persistent cough needs medical attention.", example_vn: "Ho kéo dài cần sự chú ý y tế."},
    {word: "Hypertension", meaning: "Tăng huyết áp", example_en: "Hypertension increases the risk of heart disease.", example_vn: "Tăng huyết áp làm tăng nguy cơ bệnh tim."},
    {word: "Diabetes", meaning: "Tiểu đường", example_en: "Diabetes requires blood sugar monitoring.", example_vn: "Tiểu đường cần theo dõi lượng đường trong máu."},
    {word: "Infection", meaning: "Nhiễm trùng", example_en: "An infection can cause redness and swelling.", example_vn: "Nhiễm trùng có thể gây đỏ và sưng."}
  ],
  "Tests & Diagnosis": [
    {word: "X-ray", meaning: "Chụp X-quang", example_en: "The doctor ordered an X-ray to check the bones.", example_vn: "Bác sĩ yêu cầu chụp X-quang để kiểm tra xương."},
    {word: "Blood test", meaning: "Xét nghiệm máu", example_en: "A blood test will check the patient’s hemoglobin level.", example_vn: "Xét nghiệm máu sẽ kiểm tra mức hemoglobin của bệnh nhân."},
    {word: "ECG", meaning: "Điện tâm đồ", example_en: "The ECG shows the heart's electrical activity.", example_vn: "ECG cho thấy hoạt động điện của tim."},
    {word: "Ultrasound", meaning: "Siêu âm", example_en: "Ultrasound was used to view the fetus.", example_vn: "Siêu âm được dùng để nhìn thai."},
    {word: "Biopsy", meaning: "Sinh thiết", example_en: "A biopsy removed a small tissue sample.", example_vn: "Sinh thiết lấy một mẫu mô nhỏ."}
  ],
  "Treatment & Procedures": [
    {word: "Injection", meaning: "Tiêm", example_en: "He received an injection to reduce the pain.", example_vn: "Anh ấy được tiêm để giảm đau."},
    {word: "Surgery", meaning: "Phẫu thuật", example_en: "Surgery was scheduled to remove the tumor.", example_vn: "Phẫu thuật được lên lịch để cắt bỏ khối u."},
    {word: "Physiotherapy", meaning: "Vật lý trị liệu", example_en: "Physiotherapy helps the patient regain strength.", example_vn: "Vật lý trị liệu giúp bệnh nhân phục hồi sức mạnh."},
    {word: "Vaccination", meaning: "Tiêm chủng", example_en: "Vaccination can prevent infectious diseases.", example_vn: "Tiêm chủng có thể ngăn ngừa bệnh truyền nhiễm."},
    {word: "Anesthesia", meaning: "Gây mê", example_en: "Anesthesia was given before the operation.", example_vn: "Gây mê được dùng trước ca mổ."}
  ],
  "Hospital Terms": [
    {word: "Ward", meaning: "Khoa (bệnh viện)", example_en: "The patient was moved to the surgical ward.", example_vn: "Bệnh nhân được chuyển đến khoa phẫu thuật."},
    {word: "Admission", meaning: "Nhập viện", example_en: "The admission process took some time.", example_vn: "Quy trình nhập viện mất một khoảng thời gian."},
    {word: "Discharge", meaning: "Xuất viện", example_en: "The doctor approved the discharge today.", example_vn: "Bác sĩ duyệt cho xuất viện hôm nay."},
    {word: "Emergency", meaning: "Cấp cứu", example_en: "Call the emergency number if there is a life-threatening condition.", example_vn: "Gọi cấp cứu nếu có tình trạng nguy hiểm tới tính mạng."},
    {word: "Referral", meaning: "Giới thiệu (chuyển viện/chuyển khoa)", example_en: "The GP wrote a referral to the specialist.", example_vn: "Bác sĩ gia đình viết giấy giới thiệu đến chuyên khoa."}
  ],
  "Dentistry Basics": [
    {word: "Dentist", meaning: "Nha sĩ", example_en: "I went to the dentist for a routine check-up.", example_vn: "Tôi đến nha sĩ để kiểm tra định kỳ."},
    {word: "Gum", meaning: "Nướu", example_en: "Healthy gums are important for oral health.", example_vn: "Nướu khỏe mạnh quan trọng cho sức khỏe răng miệng."},
    {word: "Cavity", meaning: "Sâu răng", example_en: "The dentist treated my cavity with a filling.", example_vn: "Nha sĩ điều trị sâu răng bằng trám."},
    {word: "Tooth extraction", meaning: "Nhổ răng", example_en: "He needed a tooth extraction because of severe decay.", example_vn: "Anh ấy cần nhổ răng vì sâu nặng."},
    {word: "Orthodontics", meaning: "Chỉnh nha", example_en: "Orthodontics helps align teeth and bite.", example_vn: "Chỉnh nha giúp sắp xếp răng và khớp cắn."}
  ]
};